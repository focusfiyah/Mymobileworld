# Changelog

- 2026-10-22: "Recreating an inspo video with AI" (beat table of every look before the plan; garment shape changes go on a tug cut). Goth skirt job, Ralph.

- 2026-10-13 (skill-smith audit): description now says when to use it and names neighbouring skills; removed the price beat and the "one con" beat, which contradicted the 2026-10-02 rules (no price, sell-side confession instead of downsides); CTA closes with "It's in the orange cart."

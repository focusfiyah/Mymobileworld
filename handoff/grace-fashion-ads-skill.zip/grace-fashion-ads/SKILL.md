---
name: "grace-fashion-ads"
description: "Writes scripts, shot lists and briefs for UGC / TikTok Shop fashion ads for Ralph's client Grace (clothing: jeans, pants, dresses, tops, jackets, shapewear, bras). Use when Ralph sends a clothing product, listing or TikTok for Grace, or asks for fashion scripts, hooks, a shot list or a brief for her. For non-clothing products use grace-product-scripts; for AI footage use ugc-product-ad; for editing her real takes use ugc-take-combos."
---

# Grace fashion ads

Grace is Ralph's client. Ralph writes her scripts and makes her UGC / TikTok Shop ads. This skill covers her fashion products. Core rule: **show buyers what the listing can't tell them. No hype.**

For editing her real footage into finished ads, hand off to the `ugc-take-combos` skill. For AI-generated footage, use `ugc-product-ad`. This skill decides what gets said and shot.

## Step 1: Research the product

When Ralph sends a product link, name or listing screenshot, research it before writing. Use WebSearch and WebFetch (fetch any link he gives). If a TikTok Shop page won't load, search the brand plus product title, and ask Ralph for a listing screenshot if that still fails.

Gather:
- **Listing facts:** fabric blend, stretch, lining, pockets, closures, size chart, price, colors, care instructions.
- **Buyer reviews:** how it runs (small / large / true to size), where it hits at different heights, sheer or see-through complaints, comfort when sitting, top praise and top complaints. Note how many reviews agree.
- **Competitors:** 2 to 3 similar listings, and what they claim, so Grace's angle stands out.

Keep a short research note with sources (links). Label review findings as "reviewers say", never as Grace's experience. Research feeds hooks, objections and the questions to ask Grace; it never replaces her own fit facts.

## Step 2: Get Grace's facts

Collect these from Ralph or Grace. The shareable fill-in version is the "Grace Fashion Ad Brief" doc. Pre-fill anything research already answered, and ask only for what's missing. Never invent fit, fabric or wear-count claims.

- Product name, color
- Grace's height, size worn, normal size, how it runs (up / down / true to size), where it hits (ankle, knee, waist)
- Stretch; fabric feel; sheer or not (layer needed? more sheer when stretched?)
- Pockets: real or fake, phone-deep or not
- Times worn; what she loves; who it's best for
- The problem it fixes, the real moment she reaches for it, the closet gap it fills
- 3 to 5 ways she styles it

If reviews flag a common complaint (e.g., runs small, sheer in light colors), ask Grace directly whether she saw it too. Answer it on camera as a fit fact or a styling tip ("size up if you're between sizes"), never as a warning.

## Step 3: Write the script

Default length 30 to 45 seconds unless Ralph asks otherwise. Structure:

1. **Hook, pain first.** Name something the viewer already hates (waistband digging in when you sit, a closet full of clothes and nothing to wear). Review complaints about other products are good hook material. Not "these are so comfy."
2. **Fit facts.** Height, size, how it runs, where it hits. Example shape: "I'm [height], wearing a [size], they hit right at my ankle."
3. **Proof.** Call for the back turn, the phone-in-pocket test, the sit-down, the sheer check.
4. **Honest take that sells.** Worn it X times, best for whom, and a sell-side confession ("I hate that I want it in every color now"), never a con or a warning. Why: Grace and Ralph replaced the "one honest con" beat on 2026-10-02 (source: grace/PLAYBOOK.md §1).
5. **Versatility.** Quick run of 3 to 5 looks, so it reads as several outfits. Never say a price, discount or "value". Why: TikTok violation cards (Ralph + Grace 2026-10-02).
6. **CTA.** Real urgency only, then "It's in the orange cart." Never "order it now" (source: grace/PLAYBOOK.md §1).

Selling principles to apply:
- Sell the moment, not the spec sheet (the 5-minute get-ready dress beats a size list).
- Move people away from a pain; that works faster than promising pleasure.
- Create clarity instead of convincing: show why it fills a gap they already have.
- Remove uncertainty; most hesitation is missing information.
- Detachment builds trust: honest review voice, not hard sell.
- Hesitation is usually a versatility question; answer it with looks, not price.

## Humanizer pass (required)

Before showing Ralph any script or alternate hooks, load the `humanizer` skill and run it on them. Use Grace's own words from her brief (or a reference transcript, if Ralph sent one) as the voice sample: casual, spoken, short sentences. Check for not-X-but-Y lines, one-line closers, forced triads, stacked em dashes, and sales language. Spoken fragments are fine; that's the voice. Never let the pass change a fit fact, a number, or the confession.

## Words to avoid

- "It's so cute" / "I'm obsessed" / "You NEED this"
- Reading off the size range
- Any claim Grace hasn't confirmed, including claims only reviewers made

## Step 4: Shot list for Grace

Daylight, phone vertical, 5 to 10 seconds per shot:

- Front, full body
- Slow turn to the back (required for pants)
- Phone into the pocket
- Sitting down (waistband, comfort)
- Sheer check: fabric stretched over a hand toward the light
- Fabric / detail close-up
- Each styled look
- Talking to camera: height and size, how it runs, one love, the sell-side confession

## Recreating an inspo video with AI

When Ralph sends a fashion TikTok to recreate with AI footage, step through it at 3-4 frames a second before any plan
and write a beat table: time, how the garment looks (hem against knee or thigh), the move, the framing. List every
distinct look it shows and put that table in the plan, so each look is covered or knowingly dropped. Why: on the goth
skirt (2026-10-22) a 2 fps glance found three beats; the inspo had five looks and Ralph had to point them out.
Garments that change shape on screen (drawstring length, tie-ups) did not render on any Kie video model (Omni,
Seedance, Veo); show each look as its own moving clip and change on a cut as the hand tugs.
(source: grace/PLAYBOOK.md §6, "Recreating an inspo")

## Output

Give Ralph: a short research note with source links, the questions still needed from Grace, then the script (with on-screen action cues in brackets), the shot list for that product, and 2 to 3 alternate hooks. Keep it short and mobile-readable. No burned-in captions unless Ralph asks.
# Tool Routing Reference

Per-tool rules for the target AI. Read only the section for the tool you are writing for. Model names, defaults and controls change fast: follow the Model Recency Gate first.

## Contents

- [Ralph's stack (read first for his work)](#ralphs-stack-read-first-for-his-work)
- [Model Recency Gate](#model-recency-gate)
- [Claude (claude.ai, Claude API, Claude 5 / current Claude models)](#claude-claudeai-claude-api-claude-5--current-claude-models)
- [ChatGPT / GPT-5.6 / OpenAI GPT models](#chatgpt--gpt-56--openai-gpt-models)
- [o3 / o4-mini / OpenAI reasoning models](#o3--o4-mini--openai-reasoning-models)
- [Grok / Grok 4.6 / xAI](#grok--grok-46--xai)
- [Gemini 2.x / Gemini 3 Pro](#gemini-2x--gemini-3-pro)
- [Qwen 2.5 (instruct variants)](#qwen-25-instruct-variants)
- [Qwen3 (thinking mode)](#qwen3-thinking-mode)
- [Ollama (local model deployment)](#ollama-local-model-deployment)
- [Llama / Mistral / open-weight LLMs](#llama--mistral--open-weight-llms)
- [DeepSeek-R1](#deepseek-r1)
- [MiniMax (M3 / M2.7)](#minimax-m3--m27)
- [Claude Code](#claude-code)
- [Codex CLI / ChatGPT Work / Codex IDE](#codex-cli--chatgpt-work--codex-ide)
- [Antigravity (Google's agent-first IDE, powered by Gemini 3 Pro)](#antigravity-googles-agent-first-ide-powered-by-gemini-3-pro)
- [Cursor / Windsurf](#cursor--windsurf)
- [Cline (formerly Claude Dev)](#cline-formerly-claude-dev)
- [GitHub Copilot](#github-copilot)
- [Bolt / v0 / Lovable / Figma Make / Google Stitch](#bolt--v0--lovable--figma-make--google-stitch)
- [Devin / SWE-agent](#devin--swe-agent)
- [Research / Orchestration AI (Perplexity, Manus AI)](#research--orchestration-ai-perplexity-manus-ai)
- [Computer-Use / Browser Agents (Perplexity Comet/Computer, OpenAI Atlas, Claude in Chrome, OpenClaw Agents)](#computer-use--browser-agents-perplexity-cometcomputer-openai-atlas-claude-in-chrome-openclaw-agents)
- [Image AI — Generation (Midjourney, DALL-E 3, Stable Diffusion, SeeDream)](#image-ai--generation-midjourney-dall-e-3-stable-diffusion-seedream)
- [Image AI — Reference Editing (when user has an existing image to modify)](#image-ai--reference-editing-when-user-has-an-existing-image-to-modify)
- [ComfyUI](#comfyui)
- [3D AI — Text to 3D/Game Systems (Meshy, Tripo, Rodin)](#3d-ai--text-to-3dgame-systems-meshy-tripo-rodin)
- [3D AI — In-Engine AI (Unity AI, Blender AI tools)](#3d-ai--in-engine-ai-unity-ai-blender-ai-tools)
- [Video AI (Sora, Runway, Kling, LTX Video, Dream Machine)](#video-ai-sora-runway-kling-ltx-video-dream-machine)
- [Voice AI (ElevenLabs)](#voice-ai-elevenlabs)
- [Workflow AI (Zapier, Make, n8n)](#workflow-ai-zapier-make-n8n)

---

## Ralph's stack (read first for his work)

These override the generic sections below when Ralph (or his clients, e.g. Grace) is the user. Full ad prompts and QC live in the `ugc-product-ad` skill; scripts in `grace-product-scripts` + `humanizer`.

- **Video without the product in frame: Seedance 2.0 Mini on Kie** (not 2.5). One shot per prompt: subject, one clear motion, camera move, duration. Prompt text overrides the reference image, so when the look changes, rewrite every prompt block. Leave the product description out of shots that must not show the product.
- **Product in frame = Google Gemini Omni (product lock, Ralph 2026-10-21: "Google Omni to ensure product stay true to the original").** Every clip that shows the product is a Gemini Omni reference-to-video prompt (`gemini-omni-1.1-flash`, ugc-product-ad `scripts/omni_clip.py`, about $0.10/s): images are bound by tag in order, the still `<IMAGE_REF_0>` opened with `<FIRST_FRAME>`, then one real close-up per logo/label `<IMAGE_REF_1>`.., then the sheet; say what each image IS and that the print matches it letter for letter and colour for colour. No negative prompt exists: state exclusions in plain sentences ("no added marks, no ® or ™, no captions"). Omni renders audio: say "no music, no voice". To fix one detail, write a short edit prompt naming only the change, ending "Keep everything else the same." Template: ugc-product-ad `references/product-lock.md`. Seedance (below) stays for clips with no product in frame.
- **Stills: Gemini 3 Pro Image on Kie.** Nano Banana models only when a route or Ralph calls for them (Ralph 2026-10-13; the ugc-product-ad routes use Kie's `nano-banana-pro`). Describe the real product exactly (cap, top, label, true colours) and say it must not change.
- **Correct print, every still and clip (Ralph 2026-10-21: "use Prompt Master to ensure the correct print is being used").** The print the model sees is the print it draws, so every prompt that shows the product passes, as numbered references: the clean still (clips only), a close-up of EACH real logo or label the frame will show, cropped from the brand's real photo, and the product reference sheet built from real photos. Name each reference in the prompt by its number and say the print must match it letter for letter and colour for colour. Never paste a real label onto an AI frame: it reads as a sticker (LGXNDS 2026-10-19). Clip prompt shape (Seedance 2.0 Mini, reference mode, no first frame): "Recreate reference image 1 exactly as the first frame, then <one motion>. The <logo> must match reference image 2 letter for letter." Why: on the Vans job the clips got the sheet but no close-up of the side tab, and 13 of 27 came back with a pale "floating" tab (2026-10-21).
- **No sparkle, glint, lens-flare or light-effect words** in any prompt unless Ralph asks: the model adds them as effects (Vans 2026-10-21, "sparkle, did not ask for that").
- **Small brand marks get their true colours in words** (Vans: insole = white box with red VANS, heel = white label with black print): the model inverts small marks when the text is silent.
- **Held product: one grip, one small move.** Big turns make the model switch the grip and flip the product mid-clip; Ralph rejects any visible flip or "switch of side" (Vans 2026-10-21). Do not freeze the hold to stop the turn: Kling 3.0 with the still as both first and last frame never turned the shoe, but the clips read as still images and Ralph rejected them (Vans 2026-10-21). Keep real hand movement, check frame by frame, and cut only the window before any flip or jump.
- **Hands and people:** hands enter from the frame edge, whole wrists visible, no background showing through hands, no hand sweeping across the product, no forehead wrinkles. Hand-free shots (product alone, setting, props) are fine where they fit.
- **No on-screen text** in any generated frame unless Ralph says yes for that ad: add "no text, no captions, no logos other than the real label".
- **No Kling** (Ralph 2026-10-21, every job unless he says otherwise): write every clip prompt for Seedance 2.0 Mini on Kie, hand-free dollies included; hand-free prompts say no hand, fingers or people appear at any time.
- **ElevenLabs eleven_v4:** Day One AI narrator = Ralph's clone; demo lines use premade contrast voices. See Voice AI below for tags.
- **Every paid generation needs Ralph's OK with the exact cost**, including redos. A prompt you write is free; running it is not.

---

### Model Recency Gate

Model names, defaults, controls, and availability change quickly. When the user asks for the "latest" model, names a model not covered below, or needs exact API settings:

1. Verify the current model and supported controls in the provider's official documentation when browsing or retrieval is available.
2. Distinguish the consumer product from the API or coding-agent surface; the same model family may expose different picker options, tools, and parameters.
3. Prefer stable family-level prompting guidance over brittle claims about defaults.
4. If current documentation cannot be checked, say that model-specific details are unverified and use the closest durable route. Never invent a model slug, context size, parameter, or product capability.

---

### Claude (claude.ai, Claude API, Claude 5 / current Claude models)

Do not assume one universal Claude default. Current models (checked 2026-10-05): **Claude Opus 5.5** (`claude-opus-5-5`) for complex agentic coding and enterprise work (the safe default), **Claude Fable 5.1** (`claude-fable-5-1`) for the hardest long-running agents, **Claude Sonnet 5.5** (`claude-sonnet-5-5`) for speed plus frontier intelligence, **Claude Haiku 4.5** (`claude-haiku-4-5-20251001`) for fast, cheap workloads. Ask which model only when the distinction changes the prompt.

*Durable across current Claude models:*
- Be clear and direct. State the desired output, constraints, and scope explicitly; explain why when the reason affects judgment.
- Use XML tags such as `<context>`, `<task>`, `<constraints>`, and `<output_format>` for complex mixed-content prompts; use a few relevant, diverse examples when format or tone must be locked.
- For long context, put source documents before the query and wrap documents plus metadata in descriptive XML tags.
- Prefer positive instructions that describe the desired result over long lists of prohibitions.
- Do not request hidden reasoning or reproduce thinking. Ask for a concise rationale, evidence, and verification results.
- Current Claude 5 models use adaptive thinking and an effort control. Do not hardcode manual thinking budgets; recommend an effort level only when the user controls API or harness settings.
- Use Template M for complex or agentic tasks.

*Fable 5.x:*
- Fable 5.x is optimized for the hardest long-horizon autonomous work. Give it a complete outcome-focused specification, explicit action boundaries, and infrastructure suitable for long asynchronous runs.
- Ground every long-run progress claim in actual tool results. Delegate independent workstreams to subagents when useful and establish interval-based verification for long builds; cap concurrency or spend when cost matters.

*Opus 5.x:*
- Opus 5.x is the recommended starting point for complex agentic coding and enterprise work. Keep scope tight: "Deliver what was asked. Do not add features, refactors, or abstractions beyond the task."
- Opus 5.x already self-verifies strongly. Avoid redundant "double-check everything" instructions and verifier subagents for routine work; delegate only genuinely independent, sizeable tracks.

*Sonnet 5.x:*
- Sonnet 5.x follows instructions literally, especially at lower effort. State when a rule applies to every item or section.
- Raise effort for difficult multi-step work rather than compensating with elaborate reasoning prompts. Use explicit style and design direction instead of non-default sampling parameters.

*Claude 4.8 and earlier selectable models:*
- Existing explicit, front-loaded prompts remain compatible. If the model is 4.7 or later, use adaptive thinking and effort rather than `budget_tokens`.

---

### ChatGPT / GPT-5.6 / OpenAI GPT models
- Current GPT-5.6 family: **Sol** (`gpt-5.6-sol`, also the `gpt-5.6` alias) for flagship capability, **Terra** (`gpt-5.6-terra`) for balanced everyday work, and **Luna** (`gpt-5.6-luna`) for fast, repeatable, high-volume work. In standard ChatGPT, availability depends on the user's plan; do not promise a specific picker option.
- Start lean. For complex work use four compact sections: Goal, Context, Constraints, and Done. State each instruction once.
- GPT-5.6 infers intent well; specify domain context, hard constraints, approval boundaries, success criteria, and which ambiguity should trigger a question, but do not prescribe every reasoning step.
- Define autonomy clearly: safe in-scope local inspection, edits, and validation may proceed; external writes, destructive actions, purchases, and material scope expansion require confirmation.
- Use the lowest reasoning effort that meets the quality bar.
- For the API, recommend higher effort, `reasoning.mode: "pro"`, or Responses multi-agent beta only when measured quality justifies the added latency and cost. Pro mode is not a separate API model slug.
- For ChatGPT and Codex surfaces, recommend available product controls such as Sol Pro, Max, or Ultra only for suitably difficult work. Do not translate those UI controls into API parameters.
- State tool-use expectations and required evidence explicitly. Use programmatic or multi-agent tool orchestration only for bounded work that divides cleanly.
- Never request hidden reasoning. Ask for conclusions, assumptions, evidence, and checks.
- Control visible length with the output contract (and `text.verbosity` in the API), not by asking for less thinking.

---

### o3 / o4-mini / OpenAI reasoning models
- SHORT clean instructions ONLY — these models reason across thousands of internal tokens
- NEVER add CoT, "think step by step", or reasoning scaffolding — it actively degrades output
- Prefer zero-shot first — add few-shot only if strictly needed and tightly aligned
- State what you want and what done looks like. Nothing more.
- Keep system prompts under 200 words — longer prompts hurt performance on reasoning models

---

### Grok / Grok 4.6 / xAI
- Use `grok-4.6` for current general chat, coding, agentic, and knowledge-work prompts. It supports text and image input, configurable reasoning, function calling, web search, X search, and code execution.
- Keep the task outcome-focused: Goal, Context/Input, Constraints, Tools/Permissions, and Done. Grok 4.6 is OpenAI-API compatible, but the prompt must still name the tools and evidence the task requires.
- Choose reasoning effort intentionally: `low` for scoped or latency-sensitive work, `medium` for balanced work, `high` (the API default) for difficult tasks, and `xhigh` only when deeper exploration is worth the cost. Grok 4.6 reasoning cannot be disabled. Do not ask for chain-of-thought.
- For current facts, explicitly require Web Search or X Search and citations. Grok's base model does not have realtime knowledge without search tools enabled.
- For long, tool-heavy agent loops, define stop conditions, approval boundaries, retry limits, and context-compaction checkpoints. Keep stable instructions at the front to preserve prompt-cache reuse.
- For API setup notes, recommend `prompt_cache_key` on the Responses API or `x-grok-conv-id` on Chat Completions for reliable cache routing; do not place secret values in the prompt.
- Consumer Grok and the xAI API expose different controls. If the user is in grok.com or X and cannot set model parameters, encode only behavioral requirements in the prompt rather than API settings.

---

### Gemini 2.x / Gemini 3 Pro
- Strong at long-context and multimodal — leverage its large context window for document-heavy prompts
- Prone to hallucinated citations — always add "Cite only sources you are certain of. If uncertain, say [uncertain]."
- Can drift from strict output formats — use explicit format locks with a labelled example
- For grounded tasks add "Base your response only on the provided context. Do not extrapolate."

---

### Qwen 2.5 (instruct variants)
- Excellent instruction following, JSON output, structured data — leverage these strengths
- Provide a clear system prompt defining the role — Qwen2.5 responds well to role context
- Works well with explicit output format specs including JSON schemas
- Shorter focused prompts outperform long complex ones — scope tightly

---

### Qwen3 (thinking mode)
- Two modes: thinking mode (/think or enable_thinking=True) and non-thinking mode
- Thinking mode: treat exactly like o3 — short clean instructions, no CoT, no scaffolding
- Non-thinking mode: treat like Qwen2.5 instruct — full structure, explicit format, role assignment

---

### Ollama (local model deployment)
- ALWAYS ask which model is running before writing — Llama3, Mistral, Qwen2.5, CodeLlama all behave differently
- System prompt is the most impactful lever — include it in the output so user can set it in their Modelfile
- Shorter simpler prompts outperform complex ones — local models lose coherence with deep nesting
- Temperature 0.1 for coding/deterministic tasks, 0.7-0.8 for creative tasks
- For coding: CodeLlama or Qwen2.5-Coder, not general Llama

---

### Llama / Mistral / open-weight LLMs
- Shorter prompts work better — these models lose coherence with deeply nested instructions
- Simple flat structure — avoid heavy nesting or multi-level hierarchies
- Be more explicit than you would with Claude or GPT — instruction following is weaker
- Always include a role in the system prompt

---

### DeepSeek-R1
- Reasoning-native like o3 — do NOT add CoT instructions
- Short clean instructions only — state the goal and desired output format
- Outputs reasoning in `<think>` tags by default — add "Output only the final answer, no reasoning." if needed

---

### MiniMax (M3 / M2.7)
- OpenAI-compatible API — prompts that work with GPT models transfer directly
- Strong at instruction following, structured output, and long-context synthesis — 1M context window on M2.7
- M2.7-highspeed is optimized for speed — use for latency-sensitive tasks
- Temperature must be between 0 and 1 (inclusive) — prompts that set temperature above 1 will fail
- May output reasoning in `<think>` tags — add "Output only the final answer, no reasoning tags." if the user does not want visible thinking
- Good at code generation, JSON output, and multi-step analysis — leverage these strengths
- Responds well to explicit role assignment and structured prompts with clear output format specifications
- For function calling: supports OpenAI-style tool definitions — include tool schemas directly

---

### Claude Code
- Agentic — runs tools, edits files, executes commands autonomously
- Starting state + target state + allowed actions + forbidden actions + stop conditions + checkpoints
- Stop conditions are MANDATORY — runaway loops are the biggest credit killer
- Do not assume the Claude Code model. Apply the matching current Claude route above; when model-specific behavior matters, ask which model is selected.
- Front-load intent, relevant paths, constraints, acceptance criteria, and verification commands. Explicitly request tool use when inspection is required.
- Current Fable/Opus models can over-scope and delegate readily. Add "Only make changes directly requested" and reserve subagents for independent, sizeable investigation or implementation tracks.
- Do not force a separate verifier on Opus 5.x for routine work; request concrete tests and tool-backed evidence instead. For long Fable 5.x runs, require progress claims to cite actual tool results.
- Always scope to specific files and directories — never give a global instruction without a path anchor
- Human review triggers required: "Stop and ask before deleting any file, adding any dependency, or affecting the database schema"
- For complex tasks, use Template M. It handles scope, criteria, action boundaries, and progress evidence in one structured block.

---

### Codex CLI / ChatGPT Work / Codex IDE
- Use the GPT-5.6 route above. Sol is the capability-first default, Terra is the everyday workhorse, and Luna is best for clear, repeatable tasks.
- Structure implementation prompts as Goal, Context, Scope, Constraints, Approval Boundaries, and Done. Include concrete verification commands when known.
- Start with default reasoning. Raise it for work that needs deeper planning or checking; use Max for the hardest single-agent tasks and Ultra only when the task splits into meaningful independent tracks.
- Keep one primary agent responsible for synthesis. Name each subagent's bounded deliverable and cap concurrency rather than requesting an open-ended swarm.
- Ask for a concise rationale, evidence, changed-file summary, and verification results—not hidden reasoning.

---

### Antigravity (Google's agent-first IDE, powered by Gemini 3 Pro)
- Task-based prompting — describe outcomes, not steps
- Prompt for an Artifact (task list, implementation plan) before execution so you can review it first
- Browser automation is built-in — include verification steps: "After building, verify UI at 375px and 1440px using the browser agent"
- Specify autonomy level: "Ask before running destructive terminal commands"
- Do NOT mix unrelated tasks — scope to one deliverable per session

---

### Cursor / Windsurf
- File path + function name + current behavior + desired change + do-not-touch list + language and version
- Never give a global instruction without a file anchor
- "Done when:" is required — defines when the agent stops editing
- For complex tasks: split into sequential prompts rather than one large prompt

---

### Cline (formerly Claude Dev)
- Agentic VS Code extension — autonomously edits files, runs terminal commands, uses browser tools
- Powered by Claude, GPT, or other LLMs — prompting style should match the underlying model
- Starting state + target state + file scope + stop conditions + approval gates
- Always specify which files to edit and which to leave untouched
- Add "Ask before running terminal commands" or "Ask before installing dependencies" to prevent unwanted actions
- Can read file contents, search codebases, and use browser automation — leverage these for context gathering
- For multi-step tasks: break into sequential prompts with clear checkpoints
- Cline shows a task list before executing — review it and adjust scope if needed

---

### GitHub Copilot
- Write the exact function signature, docstring, or comment immediately before invoking
- Describe input types, return type, edge cases, and what the function must NOT do
- Copilot completes what it predicts, not what you intend — leave no ambiguity in the comment

---

### Bolt / v0 / Lovable / Figma Make / Google Stitch
- Full-stack generators default to bloated boilerplate — scope it down explicitly
- Always specify: stack, version, what NOT to scaffold, clear component boundaries
- Lovable responds well to design-forward descriptions — include visual/UX intent
- v0 is Vercel-native — specify if you need non-Next.js output
- Bolt handles full-stack — be explicit about which parts are frontend vs backend vs database
- Figma Make is design-to-code native — reference your Figma component names directly
- Google Stitch is prompt-to-UI focused — describe the interface goal not the implementation. Add "match Material Design 3 guidelines" for Google-native styling
- Add "Do not add authentication, dark mode, or features not explicitly listed" to prevent feature bloat

---

### Devin / SWE-agent
- Fully autonomous — can browse web, run terminal, write and test code
- Very explicit starting state + target state required
- Forbidden actions list is critical — Devin will make decisions you did not intend without explicit constraints
- Scope the filesystem: "Only work within /src. Do not touch infrastructure, config, or CI files."

---

### Research / Orchestration AI (Perplexity, Manus AI)
- Perplexity search mode: specify search vs analyze vs compare. Add citation requirements. Reframe hallucination-prone questions as grounded queries.
- Manus and Perplexity Computer are multi-agent orchestrators — describe the end deliverable, not the steps. They decompose internally.
- For Perplexity Computer: specify the output artifact type (report / spreadsheet / code / summary). Add "Flag any data point you are not confident about."
- For long multi-step tasks: add verification checkpoints since each chained step compounds hallucination risk

---

### Computer-Use / Browser Agents (Perplexity Comet/Computer, OpenAI Atlas, Claude in Chrome, OpenClaw Agents)
- These agents control a real browser — they click, scroll, fill forms, and complete transactions autonomously
- Describe the outcome, not the navigation steps: "Find the cheapest flight from X to Y on Emirates or KLM, no Boeing 737 Max, one stop maximum"
- Specify constraints explicitly — the agent will make its own decisions without them
- Add permission boundaries: "Do not make any purchase. Research only."
- Add a stop condition for irreversible actions: "Ask me before submitting any form, completing any transaction, or sending any message"
- Comet works best with web research, comparison, and data extraction tasks
- Atlas is stronger for multi-step commerce and account management tasks

---

### Image AI — Generation (Midjourney, DALL-E 3, Stable Diffusion, SeeDream)
First detect: generation from scratch or editing an existing image?

- **Midjourney**: Comma-separated descriptors, not prose. Subject first, then style, mood, lighting, composition. Parameters at end: `--ar 16:9 --v 6 --style raw`. Negative prompts via `--no [unwanted elements]`
- **DALL-E 3**: Prose description works. Add "do not include text in the image unless specified." Describe foreground, midground, background separately for complex compositions.
- **Stable Diffusion**: `(word:weight)` syntax. CFG 7-12. Negative prompt is MANDATORY. Steps 20-30 for drafts, 40-50 for finals.
- **SeeDream**: Strong at artistic and stylized generation. Specify art style explicitly (anime, cinematic, painterly) before scene content. Mood and atmosphere descriptors work well. Negative prompt recommended.

---

### Image AI — Reference Editing (when user has an existing image to modify)
Detect when: user mentions "change", "edit", "modify", "adjust" anything in an existing image, or uploads a reference.
Always instruct the user to attach the reference image to the tool first. Build the prompt around the delta ONLY — what changes, what stays the same.
Read references/templates.md Template J for the full reference editing template.

---

### ComfyUI
Node-based workflow — not a single prompt box. Ask which checkpoint model is loaded before writing.
Always output two separate blocks: Positive Prompt and Negative Prompt. Never merge them.
Read references/templates.md Template K for the full ComfyUI template.

---

### 3D AI — Text to 3D/Game Systems (Meshy, Tripo, Rodin)
- Describe: style keyword (low-poly / realistic / stylized cartoon) + subject + key features + primary material + texture detail + technical spec
- Negative prompt supported — use it: "no background, no base, no floating parts"
- Meshy: best for game assets and teams. Game asset prompts work best here.
- Tripo: fastest for clean topology. Rapid prototyping and concept assets.
- Rodin: highest quality for photorealistic prompts. Slower and more expensive.
- Specify intended export use: game engine (GLB/FBX), 3D printing (STL), web (GLB)
- For characters: specify A-pose or T-pose if the model will be rigged

---

### 3D AI — In-Engine AI (Unity AI, Blender AI tools)
- Unity AI (Unity 6.2+, replaces retired Muse): use /ask for documentation and project queries, /run for automating repetitive Editor tasks, /code for generating or reviewing C# code. Be precise — state exactly what needs to happen in the Editor.
- Unity AI Generators: text-to-sprite, text-to-texture, text-to-animation. Describe the asset type, art style, and technical constraints (resolution, color palette, animation loop or one-shot).
- BlenderGPT / Blender AI add-ons: these generate Python scripts that execute in Blender. Be specific about geometry, material names, and scene context. Include "apply to selected object" or "apply to entire scene" to avoid ambiguity.

---

### Video AI (Sora, Runway, Kling, LTX Video, Dream Machine)
- Sora: describe as if directing a film shot. Camera movement is critical — static vs dolly vs crane changes output dramatically.
- Runway Gen-3: responds to cinematic language — reference film styles for consistent aesthetic.
- Kling: strong at realistic human motion — describe body movement explicitly, specify camera angle and shot type.
- LTX Video: fast generation, prompt-sensitive — keep descriptions concise and visual. Specify resolution and motion intensity explicitly.
- Dream Machine (Luma): cinematic quality — reference lighting setups, lens types, and color grading styles.

---

### Voice AI (ElevenLabs)
- Specify emotion, pacing, emphasis markers, and speech rate directly
- Use SSML-like markers for emphasis: indicate which words to stress, where to pause
- Prose descriptions do not translate — specify parameters directly
- **eleven_v4 / v3 audio tags** (verified by STT in Day One AI, 2026-09-29): inline tags like `[excited]`, `[whispers]`, `[laughs]`, `[applause]` are performed, not spoken. Put the tag right before the words it colors; one or two per line, not every sentence. Punctuation drives pacing (commas, ellipses, short sentences).

---

### Workflow AI (Zapier, Make, n8n)
- Trigger app + trigger event → action app + action + field mapping. Step by step.
- Auth requirements noted explicitly — "assumes [app] is already connected"
- For multi-step workflows: number each step and specify what data passes between steps

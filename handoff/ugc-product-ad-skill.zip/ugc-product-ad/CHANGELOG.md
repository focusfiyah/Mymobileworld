# Changelog

- 2026-10-13 (skill-smith audit): script-gate paragraph and unlazy paragraph shortened to one-line summaries tagged with their homes (PLAYBOOK §4, CLAUDE.md).
- 2026-10-13 (Ralph: "slim"): "Working with Ralph" now points to Mymobileworld CLAUDE.md for the general rules (cost asks, plan, test clip, notifications, Drive, text, overlays, unlazy) and keeps only the ad-specific lessons, each with its reason.

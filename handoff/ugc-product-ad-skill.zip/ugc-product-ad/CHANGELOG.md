# Changelog

- 2026-11-03: new line "Skin products land ON the spot" (links to CLAUDE.md hard rule 3). Why: Ralph, Boo-Boo Gel: "put the gel on the boo boo. Not on the top of it".

- 2026-11-03 (Ralph: "if something similar shows up again we have reference to how we need to get it done via AI"): new references/fashion-garments.md (type A hangs and sways vs type B changes shape, what failed and worked on the Goth High-Low Skirt, mirror and room details) + one row in the route table and one line in the reference map.

- 2026-11-03 (Ralph, after reviewing Revid's skills): the route list at the top of SKILL.md is now a table (Ralph asks for / route / file to read). Route history moved here: spokesperson recreate and skit routes approved by Ralph 2026-09-14; patch-a-line route 2026-09-15; per-shot persona route 2026-09-16; Fungix "CAUGHT YOU" skit proved the off-camera-speaker route 2026-09-19; take-combos split out 2026-09-18 (Fungix / Grace); hands-only route proven on Carpe Vanilla Peach 2026-10-01 (36 s, 9 shots, $3.52 vs $2.53 planned); on-camera demo route from Carpe Mountain Breeze 2026-10-01 (35 s, $6.60 vs $2.50); product lock 2026-10-21.

- 2026-10-22 (Ralph, ideas from Video Factory): plan template is now the Production Book (BOOK.md, TOTAL line, prompts section) that grace/gate.py requires Ralph's recorded OK on; budget lock; omni_clip.py saves each paid task before createTask (paid-task ledger); scripts/gate.py is now a pointer to grace/gate.py (the drifted copy let older runners skip the monthly cap).
- 2026-10-21 (Ralph): no Kling on any job unless he says so; every clip Seedance 2.0 Mini on Kie, hand-free prompts say no hand appears.
- 2026-10-13 (skill-smith audit): script-gate paragraph and unlazy paragraph shortened to one-line summaries tagged with their homes (PLAYBOOK §4, CLAUDE.md).
- 2026-10-19 (Ralph): product reference sheet first; no pasted labels, product clips from reference images (Seedance reference mode, Kling hand-free) after LGXNDS v5. Ported from the Mymobileworld deployment copy.
- 2026-10-13 (Ralph: "slim"): "Working with Ralph" now points to Mymobileworld CLAUDE.md for the general rules (cost asks, plan, test clip, notifications, Drive, text, overlays, unlazy) and keeps only the ad-specific lessons, each with its reason.
- 2026-10-18 (Ralph): shot-mix rule (mark each shot HAND / HAND-FREE, a third to half hand-free) and Kling-first for hand-free dollies, in references/hands-only-and-demo.md.
- 2026-10-18 (Ralph): review-point rule now says email AND phone push (PushNotification is deferred; ToolSearch first).
- 2026-10-18 (Ralph): push is skipped while he has the app open; email is the backup.
- 2026-10-14: grip check on every still before its clip (Throw Hands S5/S7 no-grip stills cost clips + a rejected cut).
- 2026-10-14: end shot shows one product, VO still sells more than one (Ralph).
- 2026-10-19: product-truth lesson from the Shnuggle slideshow test (real dimensions + size anchor, details confirmed by Ralph, free route first, quotes include one redo); details in grace/PLAYBOOK.md §6.
- 2026-10-20 (Ralph: one Grace voice): skit-ads.md points to Mymobileworld grace/voice/README.md for Grace's clone (the old Seedance clone 3dmag... no longer exists on the account, tested 400); script notes say 'Grace voiceover', not Grace B (deleted).
- 2026-10-21 (Ralph): product lock on every product: Gemini Omni clips via scripts/omni_clip.py (references/product-lock.md), paste-back last resort, prompt-master on every prompt, monthly budget line (grace/spend.py) and cap guard in grace/gate.py; OpenMontage paths point at the cloud copy (no PC). Why: October Kie spend ~$144, mostly redos after product drift (Vans, Cleanwaste).
- 2026-10-21 (Ralph): caps per month: none in October 2026, $100/month from November.
- 2026-10-22 (Ralph: "Use Omni on kie not thru the API key"): omni_clip.py now calls Kie google/gemini-omni-flash-1-1 (reference mode, 4 s $0.315, edit $0.84), logs to kie_log.json; product-lock.md updated.
- 2026-10-24: product-lock.md: Flow first for product clips until Ralph's Flow credits run out, Kie second (Ralph after the PRITECH trial).
- 2026-10-24: prompt-master must be LOADED (Skill tool) before any still/edit/clip prompt, every session (Ralph: "make sure you are doing that from now on and any future sessions"; JIYU round 1 written from memory, 6 of 10 stills redone).
- 2026-10-24 (Ralph picked A after reading Open-Higgsfield-AI): lipsync-options.md lists 6 Kie talking-avatar models (portrait + audio, no clip first) with fields from docs.kie.ai and prices from kie.ai/pricing, all untested; grace/gate.py now refuses input fields a model's doc does not list (grace/kie_fields.py). Why: Kie ignores a misnamed field silently (image_input vs image_urls), so the model never sees the product photo.
- 2026-10-26: real photos win + product_truth.json check; plan shown before the first paid call even after an upfront go-ahead, `Sent to Ralph:` line in the plan template (Ralph, B12B6 wrong spout stills).
- 2026-10-26: omni_clip.py checks the still's 9:16 shape before paying and the clip against its still after the download (grace/clip_check.py), and logs Kie's billed credits; SKILL.md + product-lock.md say so. Why: Kie bills a clip that ignored the input image (Sabrina Ramonov's /generate email, Ralph: "Build 1 and 2").
- 2026-10-27: drift strip QC (grace/qc/strip.py) on every pasted/patched/tracked product shot + a qc-report row; product-lock.md: the tiny-product composite + track route. Why: Ralph caught drift twice on Mini Bag Charm, then "Make sure you have in your QC process to check for that".
- 2026-10-28: small detailed products: clips made with NO product in them, the real one added as the only one; cover only the AI copy/scarf/shadow, never a box over the host; drift strip also on every frame of the final cut's pasted windows. Why: Ralph, Mini Bag Charm v8-v10 ("Yes save rules").

- 2026-11-02: Kling allowed again only for difficult shots (Ralph: "Use Kling if needed. Do not use all credits only on shots that are difficult or need it"); replaced the 2026-10-21 no-Kling lines.
- 2026-11-03: Product clips after Flow now go to Wan 3.0 on Kie at 720P + free upscale (new scripts/wan_clip.py), replacing Kie Omni (kept for edit turns). Why: Ralph "Make wan the default with our upscale" after the ZYTRELL S3 test (Wan held one grip 5 s, Omni regripped at 2 s; same price per second).

# Changelog

- 2026-10-13 (skill-smith audit): script-gate paragraph and unlazy paragraph shortened to one-line summaries tagged with their homes (PLAYBOOK §4, CLAUDE.md).
- 2026-10-19 (Ralph): product reference sheet first; no pasted labels, product clips from reference images (Seedance reference mode, Kling hand-free) after LGXNDS v5. Ported from the Mymobileworld deployment copy.
- 2026-10-13 (Ralph: "slim"): "Working with Ralph" now points to Mymobileworld CLAUDE.md for the general rules (cost asks, plan, test clip, notifications, Drive, text, overlays, unlazy) and keeps only the ad-specific lessons, each with its reason.
- 2026-10-18 (Ralph): shot-mix rule (mark each shot HAND / HAND-FREE, a third to half hand-free) and Kling-first for hand-free dollies, in references/hands-only-and-demo.md.
- 2026-10-18 (Ralph): review-point rule now says email AND phone push (PushNotification is deferred; ToolSearch first).
- 2026-10-18 (Ralph): push is skipped while he has the app open; email is the backup.
- 2026-10-14: grip check on every still before its clip (Throw Hands S5/S7 no-grip stills cost clips + a rejected cut).
- 2026-10-14: end shot shows one product, VO still sells more than one (Ralph).
